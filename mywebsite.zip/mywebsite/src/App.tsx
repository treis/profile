import { useState, type ReactElement } from 'react'
import bg from "./assets/bg.png";
import treis from"./assets/treis.svg"


function About() {
  return (
    <>
    <section class="flex flex-row w-2/3 bg-gray-900 border-gray-700 g-gray-900 animate-fly-in-up m-20 p-8 shadow-2xl shadow-black border-3 border-gray-600 rounded-lg">

      <article class="text-lg">

        <h1 class="text-xl font-bold text-gray-600 mb-2">
          About Me
        </h1>

        <p class="text-white">
        "Hello, hello? Uh, I wanted to record a message for you to help you get settled in on your first night. Um, I actually worked in that office before you. I'm finishing up my last week now, as a matter of fact. So, I know it can be a bit overwhelming, but I'm here to tell you there's nothing to worry about. Uh, you'll do fine. So, let's just focus on getting you through your first week. Okay?Uh, let's see, first there's an introductory greeting from the company that I'm supposed to read. Uh, it's kind of a legal thing, you know. Um, "Welcome to Freddy Fazbear's Pizza. A magical place for kids and grown-ups alike, where fantasy and fun come to life. Fazbear Entertainment is not responsible for damage to property or person. Upon discovering that damage or death has occurred, a missing person report will be filed within 90 days, or as soon property and premises have been thoroughly cleaned and bleached, and the carpets have been replaced."

 
        </p>
      </article>

      <img src="https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/fb6a00b4-9cdc-401d-9a61-41fdbe9d09ce/dfp47uj-1514a901-47a6-48cf-8ed1-ebbdd7c5ad3a.png/v1/fill/w_1280,h_1185/freddy_fazbear__render__by_yessing_dfp47uj-fullview.png?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7ImhlaWdodCI6Ijw9MTE4NSIsInBhdGgiOiJcL2ZcL2ZiNmEwMGI0LTljZGMtNDAxZC05YTYxLTQxZmRiZTlkMDljZVwvZGZwNDd1ai0xNTE0YTkwMS00N2E2LTQ4Y2YtOGVkMS1lYmJkZDdjNWFkM2EucG5nIiwid2lkdGgiOiI8PTEyODAifV1dLCJhdWQiOlsidXJuOnNlcnZpY2U6aW1hZ2Uub3BlcmF0aW9ucyJdfQ.Pu4z-aumszUPuHZ_JpvyLDjmxuf7OtV5q-ZSy7IPQ1Q"
        class="w-1/3">
      </img>

    </section>

    </>
  )
}

function App() {

  const [card, setCard] = useState(<About/>);

  function changeCard(newCard: ReactElement) {
    setCard(newCard)
  }

  return (
    <>
    <body>

      <header class="flex justify-center pt-5 md:justify-end">

          <nav class="space-x-12 border-gray-800 text-white font-extrabold font-mono mb-2 w-1/3 text-xl">

            <a class="hover:underline  decoration-red-800 decoration-2" href="www.">HOME</a>

            <button
              className="hover:underline decoration-green-600 decoration-2"
              onClick={() => changeCard(<About />)}
            >
              ABOUT
            </button>

            <a class="hover:underline decoration-green-600 decoration-2" href="www.">RESUME</a>
            <a class="hover:underline decoration-green-600 decoration-2" href="www.">CONTACT</a>

          </nav>

      </header>

      <div class="h-1 w-full justify-end bg-gradient-to-r from-sky-500/0 via-blue-300/70 to-sky-500/0"></div>

      <main>

        <section> 

          <article class="pt-20 pl-20">

          <p class="text-white flex justify-start text-5xl mb-4 font-bold">Thiago</p>

          <h1 class="text-white text-2xl animate-typing overflow-hidden mb-3">
            Actively Learns On The Job To Deliver <span class="bg-gradient-to-r from-blue-500 to-cyan-400 bg-clip-text text-transparent font-extrabold"> Real </span>Results
          </h1>

          <article/>

          <article class="shadow-2xl"/>

            {card}

          </article>

        </section>

      </main>

    </body>
    </>
  )
}

export default App